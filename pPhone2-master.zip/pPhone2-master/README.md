This is not my script, it is from pichotm#6445 (https://github.com/PichotM), all credits goes to him. Don't contact me for this script. Thank you

# pPhone2
<br/>

<p align="center">
  <a href="https://travis-ci.com/PichotM/pPhone2/"><img src="https://travis-ci.com/PichotM/pPhone2.svg?branch=master" alt="Travis CI Builds"></a>
  <a href="#"><img src="https://cdn.rawgit.com/aleen42/badges/master/src/webpack.svg" alt="Webpack Badge"></a>
  <a href="#"><img src="https://cdn.rawgit.com/aleen42/badges/master/src/react.svg" alt="React Badge"></a>
  <a href="#"><img src="https://cdn.rawgit.com/aleen42/badges/master/src/node.svg" alt="Node.js"></a>
  <a href="#"><img src="https://cdn.rawgit.com/aleen42/badges/master/src/typescript.svg" alt="Typescript"></a>
  <a href="#"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="GitHub license"></a>
</p>

----

WIP **interactive** smartphone user interface, based on iPhone UI style.

## Preview

![](https://i.imgur.com/k6BJtj2.png)
![](https://i.imgur.com/DicKs1B.png)
